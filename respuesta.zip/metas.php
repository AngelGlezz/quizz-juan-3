<?php
	$metas = array(
		"mal" => array(
			"title" => "sólo para verdaderos conocedores del fut mexa",
			"description" => "¡¿De qué te vas a disfraza?!",
			"image" => "images/metas/0.png" 
		),
		"chavo" => array(
			"title" => "sólo para verdaderos conocedores del fut mexa",
			"description" => "Estas chavo, chavo",
			"image" => "images/metas/1.png" 
		)
		,
		"defiendes" => array(
			"title" => "sólo para verdaderos conocedores del fut mexa",
			"description" => "Te defiendes",
			"image" => "images/metas/2.png" 
		)
		,
		"mrchip" => array(
			"title" => "sólo para verdaderos conocedores del fut mexa",
			"description" => "Eres un experto, el Mr. Chip mexicano",
			"image" => "images/metas/3.png" 
		)
	);